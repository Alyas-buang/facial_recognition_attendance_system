<?php define("MODE", "recognize"); ?>
<!DOCTYPE html>
<html>
<head>
  <link rel="icon" href="data:,">
  <title>Attendance & Recognition</title>
  <script defer src="https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.min.js"></script>
  <style>
    body { font-family: Arial, sans-serif; text-align: center; margin-top: 20px; }
    button { margin: 5px; padding: 6px; font-size: 14px; }
    .video-container {
      position: relative;
      display: inline-block;
      margin-bottom: 20px;
    }
    video, canvas {
      border: 1px solid #ccc;
      border-radius: 6px;
    }
    canvas {
      position: absolute;
      top: 0;
      left: 0;
    }
    #status { margin: 10px; font-weight: bold; }
    table { border-collapse: collapse; width: 80%; margin: 20px auto; }
    th, td { border: 1px solid #ccc; padding: 8px; text-align: center; }
    th { background: #f2f2f2; }
  </style>
</head>
<body>
  <h1>Attendance & Recognition</h1>
  <button id="startCam">Start Camera</button><br>

  <div class="video-container">
    <video id="video" width="400" height="300" autoplay muted></video>
    <canvas id="overlay" width="400" height="300"></canvas>
  </div>

  <p id="status">Idle...</p>

  <!-- Attendance table -->
  <h2>Attendance Logs</h2>
  <table id="attendanceTable">
    <thead>
      <tr>
        <th>Student Number</th>
        <th>Name</th>
        <th>Last Seen</th>
      </tr>
    </thead>
    <tbody>
      <tr><td colspan="3">No records yet</td></tr>
    </tbody>
  </table>

  <script>const MODE = "<?php echo MODE; ?>";</script>
  <script defer src="capture.js"></script>
  <script>
    // Refresh attendance logs dynamically
    async function loadAttendance() {
      try {
        const res = await fetch("attendance_api.php"); // new API endpoint
        const data = await res.json();
        const tbody = document.querySelector("#attendanceTable tbody");
        tbody.innerHTML = "";
        if (data.length === 0) {
          tbody.innerHTML = "<tr><td colspan='3'>No attendance records</td></tr>";
        } else {
          data.forEach(row => {
            tbody.innerHTML += `
              <tr>
                <td>${row.student_number}</td>
                <td>${row.name}</td>
                <td>${row.timestamp}</td>
              </tr>`;
          });
        }
      } catch (err) {
        console.error("[attendance fetch error]", err);
      }
    }

    // Auto-refresh every 10 seconds
    setInterval(loadAttendance, 10);
    loadAttendance();
  </script>
</body>
</html>
