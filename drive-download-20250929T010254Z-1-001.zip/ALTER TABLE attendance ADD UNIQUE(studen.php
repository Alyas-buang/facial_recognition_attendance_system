<?php
ALTER TABLE attendance ADD UNIQUE(student_id);
?>